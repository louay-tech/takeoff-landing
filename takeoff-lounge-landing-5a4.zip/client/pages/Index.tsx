import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Progress } from "@/components/ui/progress";
import { Instagram, Phone, Mail, MapPin, Coffee, Users, Star, Clock } from "lucide-react";
import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";
import { motion, useAnimation } from "framer-motion";
import { useInView } from "react-intersection-observer";

export default function Index() {
  const [isVisible, setIsVisible] = useState(false);
  const [selectedDay, setSelectedDay] = useState("Saturday");

  useEffect(() => {
    setIsVisible(true);
    // Force dark mode on this page
    document.documentElement.classList.add("dark");
  }, []);

  const stats = [
    { range: "DZD 1–1,000", percent: 25 },
    { range: "DZD 1,000–2,000", percent: 40 },
    { range: "DZD 2,000–3,000", percent: 20 },
    { range: "DZD 3,000–4,000", percent: 15 },
  ];

  const highlights = [
    {
      icon: <Users className="w-6 h-6 text-primary" />,
      title: "Friendly Staff",
      description: "Welcoming atmosphere that makes you feel at home."
    },
    {
      icon: <Coffee className="w-6 h-6 text-primary" />,
      title: "Premium Refreshments",
      description: "Great coffee & dessert options to enjoy while you browse."
    },
    {
      icon: <Star className="w-6 h-6 text-primary" />,
      title: "Modern Lounge Vibe",
      description: "Cozy, modern setting perfect for any occasion."
    },
    {
      icon: <Clock className="w-6 h-6 text-primary" />,
      title: "Versatile Space",
      description: "Popular for lunch, dinner & casual meetings."
    }
  ];

  const days = ["Saturday", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];

  const activityData: Record<string, number[]> = {
    "Saturday": [20, 30, 45, 60, 80, 100, 95, 85, 70, 60, 50, 40, 30, 20],
    "Sunday": [15, 25, 40, 55, 75, 90, 85, 75, 65, 55, 45, 35, 25, 15],
    "Monday": [10, 20, 35, 50, 65, 80, 75, 65, 55, 45, 35, 25, 15, 10],
    "Tuesday": [12, 22, 37, 52, 67, 82, 77, 67, 57, 47, 37, 27, 17, 12],
    "Wednesday": [14, 24, 39, 54, 69, 84, 79, 69, 59, 49, 39, 29, 19, 14],
    "Thursday": [25, 40, 55, 70, 90, 100, 100, 95, 85, 75, 65, 55, 40, 25],
    "Friday": [30, 50, 70, 85, 100, 100, 100, 100, 90, 80, 70, 60, 45, 30],
  };

  return (
    <div className="min-h-screen bg-background text-foreground selection:bg-primary/30">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden px-4">
        {/* Background Glow */}
        <div className="absolute inset-0 z-0">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 2 }}
            className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-[120px]"
          />
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 2, delay: 1 }}
            className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-cyan-500/5 rounded-full blur-[120px]"
          />
        </div>

        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="relative z-10 text-center max-w-4xl"
        >
          <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-6">
            TakeOff Lounge – <span className="text-primary gold-glow text-shadow-gold">Phones & Computers</span>, Redefined
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground mb-10 max-w-2xl mx-auto">
            Discover the ultimate devices with premium service and style.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className="gold-gradient gold-glow gold-glow-hover text-black font-semibold rounded-full px-8 py-6 text-lg transition-all duration-300"
              asChild
            >
              <a href="https://www.instagram.com/takeoff_lounge?igsh=cjFjbm1weGJucWY4" target="_blank" rel="noopener noreferrer">
                Our Products <Instagram className="ml-2 w-5 h-5" />
              </a>
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="border-primary/50 text-primary hover:bg-primary/10 rounded-full px-8 py-6 text-lg transition-all duration-300"
              onClick={() => document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })}
            >
              Contact Us
            </Button>
          </div>
        </motion.div>

        {/* Scroll Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.5 }}
          transition={{ delay: 2 }}
          className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce"
        >
          <div className="w-6 h-10 border-2 border-primary rounded-full flex justify-center pt-2">
            <div className="w-1 h-2 bg-primary rounded-full" />
          </div>
        </motion.div>
      </section>

      {/* Highlights Section */}
      <section className="py-24 px-4 bg-secondary/30 overflow-hidden">
        <div className="max-w-6xl mx-auto">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl md:text-4xl font-bold text-center mb-16"
          >
            Why <span className="text-primary">Customers Love Us</span>
          </motion.h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {highlights.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="bg-card/50 border-primary/10 hover:border-primary/30 transition-all duration-300 group h-full">
                  <CardContent className="pt-6">
                    <div className="mb-4 transform group-hover:scale-110 transition-transform duration-300">
                      {item.icon}
                    </div>
                    <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                    <p className="text-muted-foreground">{item.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Statistics Section */}
      <section className="py-24 px-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto"
        >
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="stats" className="border-none">
              <AccordionTrigger className="hover:no-underline group">
                <div className="bg-primary/10 border border-primary/20 rounded-full px-8 py-4 flex items-center gap-3 group-hover:bg-primary/20 transition-all duration-300 w-full text-left">
                  <span className="text-xl font-semibold text-primary">Statistics – Price per Person</span>
                  <div className="ml-auto bg-primary text-black text-xs font-bold px-2 py-0.5 rounded">NEW</div>
                </div>
              </AccordionTrigger>
              <AccordionContent>
                <Card className="bg-card border-primary/10 mt-4 overflow-hidden shadow-2xl">
                  <CardContent className="pt-8">
                    <div className="flex items-center justify-between mb-8">
                      <div>
                        <h4 className="text-2xl font-bold">Price per person</h4>
                        <p className="text-muted-foreground">174 people reported</p>
                      </div>
                      <Star className="text-primary w-8 h-8 fill-primary/20" />
                    </div>
                    <div className="space-y-8">
                      {stats.map((stat, index) => (
                        <div key={index} className="space-y-2">
                          <div className="flex justify-between text-sm font-medium">
                            <span>{stat.range}</span>
                            <span className="text-primary">{stat.percent}%</span>
                          </div>
                          <Progress
                            value={isVisible ? stat.percent : 0}
                            className="h-2 bg-secondary"
                            indicatorClassName="gold-gradient gold-glow"
                          />
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </motion.div>
      </section>

      {/* Popular Times */}
      <section className="py-24 px-4 bg-secondary/10">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto"
        >
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="times" className="border-none">
              <AccordionTrigger className="hover:no-underline group">
                <div className="bg-secondary/50 border border-primary/10 rounded-full px-8 py-4 flex items-center gap-3 group-hover:bg-secondary/80 transition-all duration-300 w-full text-left">
                  <Clock className="w-5 h-5 text-primary" />
                  <span className="text-xl font-semibold">Popular Times</span>
                </div>
              </AccordionTrigger>
              <AccordionContent>
                <Card className="bg-card border-primary/10 mt-4 overflow-hidden shadow-2xl">
                  <CardContent className="pt-8">
                    <div className="flex flex-col md:flex-row items-center justify-between mb-8 gap-4">
                      <div className="space-y-1">
                        <h4 className="text-xl font-semibold">Weekly Activity</h4>
                        <div className="flex gap-2">
                          <div className="flex items-center gap-1 text-xs">
                            <div className="w-2 h-2 rounded-full bg-green-500" /> Not busy
                          </div>
                          <div className="flex items-center gap-1 text-xs">
                            <div className="w-2 h-2 rounded-full bg-red-500" /> Peak
                          </div>
                        </div>
                      </div>
                      <div className="flex flex-wrap justify-center gap-2">
                        {days.map(day => (
                          <button
                            key={day}
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedDay(day);
                            }}
                            className={cn(
                              "px-3 py-1 text-xs rounded-full border transition-all duration-300",
                              selectedDay === day
                                ? "bg-primary text-black border-primary font-bold"
                                : "bg-secondary text-muted-foreground border-primary/10 hover:border-primary/30"
                            )}
                          >
                            {day.slice(0, 3)}
                          </button>
                        ))}
                      </div>
                    </div>
                    {/* Simulated Chart */}
                    <div className="flex items-end justify-between h-48 gap-1 md:gap-2">
                      {activityData[selectedDay].map((h, i) => (
                        <motion.div
                          key={`${selectedDay}-${i}`}
                          initial={{ height: 0 }}
                          animate={{ height: `${h}%` }}
                          transition={{ duration: 0.5, delay: i * 0.03 }}
                          className={cn(
                            "w-full rounded-t-sm relative group/bar",
                            h > 80 ? "bg-red-500" : h > 60 ? "bg-orange-500" : h > 40 ? "bg-yellow-500" : "bg-green-500"
                          )}
                        >
                          <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-black text-white text-[10px] px-1.5 py-0.5 rounded opacity-0 group-hover/bar:opacity-100 transition-opacity pointer-events-none whitespace-nowrap border border-white/20 z-20">
                            {h}% Busy
                          </div>
                        </motion.div>
                      ))}
                    </div>
                    <div className="flex justify-between mt-4 text-[10px] md:text-xs text-muted-foreground">
                      <span>9 AM</span>
                      <span>12 PM</span>
                      <span>3 PM</span>
                      <span>6 PM</span>
                      <span>9 PM</span>
                    </div>
                  </CardContent>
                </Card>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </motion.div>
      </section>

      {/* Products CTA */}
      <section className="py-24 px-4 text-center overflow-hidden">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto bg-primary/5 rounded-3xl p-12 border border-primary/10 relative"
        >
          <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
          <h2 className="text-4xl font-bold mb-6">Explore Our Full Range</h2>
          <p className="text-xl text-muted-foreground mb-10">
            From the latest smartphones to high-performance computers, find it all on our Instagram.
          </p>
          <Button
            size="lg"
            className="gold-gradient gold-glow gold-glow-hover text-black font-semibold rounded-full px-12 py-8 text-xl transition-all duration-300"
            asChild
          >
            <a href="https://www.instagram.com/takeoff_lounge?igsh=cjFjbm1weGJucWY4" target="_blank" rel="noopener noreferrer">
              Check Products <Instagram className="ml-3 w-6 h-6" />
            </a>
          </Button>
        </motion.div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 px-4 bg-background">
        <div className="max-w-6xl mx-auto">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl md:text-5xl font-bold text-center mb-16"
          >
            Get in <span className="text-primary">Touch</span>
          </motion.h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { href: "tel:0557395808", icon: <Phone />, label: "Call Now", value: "0557395808" },
              { href: "mailto:nitro1006@live.fr", icon: <Mail />, label: "Email Us", value: "nitro1006@live.fr" },
              { href: "https://www.google.com/maps/search/?api=1&query=Rue+Diabaoui+Hadda,+Constantine", icon: <MapPin />, label: "Visit Store", value: "Rue Diabaoui Hadda, Constantine" }
            ].map((contact, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <Button
                  variant="outline"
                  className="w-full h-32 border-primary/20 hover:border-primary flex flex-col gap-2 rounded-2xl group transition-all duration-300"
                  asChild
                >
                  <a href={contact.href} target={contact.href.startsWith("http") ? "_blank" : undefined} rel="noopener noreferrer">
                    {contact.icon && <contact.icon.type className="w-8 h-8 text-primary group-hover:scale-110 transition-transform" />}
                    <span className="text-lg">{contact.label}</span>
                    <span className="text-sm text-muted-foreground line-clamp-1">{contact.value}</span>
                  </a>
                </Button>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 border-t border-primary/10 bg-black/50">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            className="text-2xl font-bold tracking-tighter"
          >
            TAKEOFF<span className="text-primary">LOUNGE</span>
          </motion.div>
          <div className="flex gap-6">
            <a href="https://www.instagram.com/takeoff_lounge?igsh=cjFjbm1weGJucWY4" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-colors">
              <Instagram className="w-6 h-6" />
            </a>
          </div>
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} TakeOff Lounge. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}
